import { Form, Button, FormControl } from 'react-bootstrap';

const CategoryForm = () => {
  return (
    <Form>
      <Form.Group>
        <Form.Label>Id:</Form.Label>
        <FormControl type="text" name="id" />
      </Form.Group>

      <Form.Group>
        <Form.Label>Nombre:</Form.Label>
        <FormControl type="text" name="nombre" />
      </Form.Group>

      {/* Resto del formulario y botones */}
    </Form>
  );
};

export default CategoryForm;