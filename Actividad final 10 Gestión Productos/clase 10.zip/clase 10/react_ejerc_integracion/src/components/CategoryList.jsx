import React, { useEffect, useState } from 'react';
import { Table } from 'react-bootstrap';
const CategoryList = () => {
    const [categories, setCategories] = useState([]);
  
    useEffect(() => {
      fetchCategories();
    }, []);
  
    const fetchCategories = async () => {
      try {
        const response = await fetch('https://backend-productos.netlify.app/api/categorias');
        const data = await response.json();
        setCategories(data);
      } catch (error) {
        console.error(error);
      }
    };
  
    return (
      <div>
        return (
  <div>
    <h1>Listado de Categorías</h1>
    <Table striped bordered>
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
        </tr>
      </thead>
      <tbody>
        {categories.map((category) => (
          <tr key={category.id}>
            <td>{category.id}</td>
            <td>{category.nombre}</td>
          </tr>
        ))}
      </tbody>
    </Table>
  </div>
);
      </div>
    );
  };
  
  export default CategoryList;